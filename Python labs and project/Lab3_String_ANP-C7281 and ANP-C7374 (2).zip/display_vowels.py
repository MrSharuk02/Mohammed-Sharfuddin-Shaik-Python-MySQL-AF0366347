# Function to count and display vowels in a text
def count_and_display_vowels(text):
    # Define a set of vowels
    vowels = {'a', 'e', 'i', 'o', 'u'}
    # Initialize a variable to count the number of vowels
    vowel_count = 0
    # Initialize an empty string to store the vowels found
    vowel_string = ""

    # Convert the text to lowercase to make it case-insensitive
    text = text.lower()

    # Iterate through each character in the text
    for char in text:
        # Check if the character is a vowel
        if char in vowels:
            # Increment the vowel count
            vowel_count += 1
            # Append the vowel to the vowel string
            vowel_string += char + " "

    # Print the number of vowels and the vowels found
    print("Number of vowels:", vowel_count)
    print("Vowels found:", vowel_string)

# Take user input for the text
input_text = input("Enter a text: ")
# Call the count_and_display_vowels function with the user-provided text
count_and_display_vowels(input_text)
