# Function to count occurrences of each word in a sentence
def count_words(sentence):
    # Convert the sentence to lowercase to make the word count case-insensitive
    sentence = sentence.lower()
    # Split the sentence into words
    words = sentence.split()
    # Create an empty dictionary to store word counts
    word_count = {}
    # Iterate through each word in the list of words
    for word in words:
        # Check if the word is already in the dictionary
        if word in word_count:
            # If the word is already in the dictionary, increment its count by 1
            word_count[word] += 1
        else:
            # If the word is not in the dictionary, add it with a count of 1
            word_count[word] = 1
    # Return the dictionary containing word counts
    return word_count

# Take user input for the sentence
sentence = input("Enter a sentence: ")
# Call the count_words function with the user-provided sentence
word_counts = count_words(sentence)
# Print the word counts
print("Word Counts:")
for word, count in word_counts.items():
    print(f"'{word}': {count}")
