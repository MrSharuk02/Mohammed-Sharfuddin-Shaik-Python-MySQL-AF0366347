# Function to remove newline characters from a string
def remove_newlines(string):
    # Replace newline characters with an empty string
    string_without_newlines = string.replace("\n", "")
    # Return the modified string
    return string_without_newlines

# Take user input for the string
input_string = input("Enter a string with newline characters: ")
# Call the remove_newlines function with the user-provided string
string_without_newlines = remove_newlines(input_string)
# Print the modified string
print("String without newlines:", string_without_newlines)
