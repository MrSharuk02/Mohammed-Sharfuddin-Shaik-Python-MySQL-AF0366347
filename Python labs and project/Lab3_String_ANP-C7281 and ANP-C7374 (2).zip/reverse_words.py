# Function to reverse words in a string
def reverse_words(string):
    # Split the string into words
    words = string.split()
    # Reverse the order of the words
    reversed_words = words[::-1]
    # Join the reversed words back into a string
    reversed_string = ' '.join(reversed_words)
    # Return the reversed string
    return reversed_string

# Take user input for the string
input_string = input("Enter a string: ")
# Call the reverse_words function with the user-provided string
reversed_string = reverse_words(input_string)
# Print the reversed string
print("Reversed string:", reversed_string)
