''' Area of Square '''
S = int(input("Enter the length of side: "))        #User input for length
Area = S**2                                         #Formula for the Area
print("The Area of Square is",Area)                 #Output printing

