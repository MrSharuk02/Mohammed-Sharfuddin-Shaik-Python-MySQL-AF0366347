''' Area of Triangle '''
B = int(input("Enter the base of the triangle:"))   #User input for Base
H = int(input("Enter the height of the triangle:")) #User input for Height
Area = (B*H)/2                                      #Formula for the Area
print(Area)                                         #Output printing
