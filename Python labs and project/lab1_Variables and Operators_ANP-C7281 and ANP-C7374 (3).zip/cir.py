''' Area of circle '''
PI = 3.14 #PI value constant
r = int(input("Enter the Radious:")) #input the radious
Area = PI*(r**2) #Formula of Circle
print("The Area of circle is",Area)
