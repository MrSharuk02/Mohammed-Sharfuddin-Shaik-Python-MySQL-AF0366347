''' Area of rectangle '''
L = int(input("Enter the length of Rectangle: "))   #User input for length
W = int(input("Enter the width of Rectangle: "))    #User input for Width
Area = L*W                                          #Formula for the Area
print("The Area of rectangle is",Area)              #Output printing

