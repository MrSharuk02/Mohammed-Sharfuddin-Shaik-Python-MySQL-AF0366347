#Import the libreries 
import numpy as np
import matplotlib.pyplot as plt
#Defining the Variables and assigning the values to them  
square_footage = np.array([1200,1400,1600,1800,2000,2200,2400,2600,2800,3000])
selling_prices = np.array([250,290,315,380,410,450,500,525,570,610])

plt.xlabel("square_footage (sq.ft)")          #--> This is label for xaxis
plt.ylabel("selling_prices $1000's")         #--> This is label for yaxis
plt.title("Housing price Vs Square footage") #--> This is Title for Graph
plt.grid(True)                               #--> It will give grids 
plt.scatter(square_footage, selling_prices, c = 'green')    #--> ploting scatter graph with color green 
plt.show()                                                  #--> show() will plot the graph    
