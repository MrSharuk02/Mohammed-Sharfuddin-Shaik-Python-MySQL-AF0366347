#Imporing the libraries
import numpy as np
import matplotlib.pyplot as plt
#Defining variables
incoming_sources = ['Salary', 'Freelance', 'Investments', 'Rental', 'Other']
monthly_income = [5000, 1500, 1000, 600, 400]
plt.title("Income source and their monthly incomes")    #--> This will give Title to the Graph
plt.pie(monthly_income, labels = incoming_sources, autopct = '%1.1f%%') #--> It generates the pie Chart with label of income_sources
plt.show()                                          #--> show() will gives Graph as output 
