# Function to count letters, digits, and special symbols in a string
def count_characters(input_string):
    # Initialize variables to count letters, digits, and symbols
    letter_count = 0
    digit_count = 0
    symbol_count = 0

    # Iterate through each character in the input string
    for char in input_string:
        # Check if the character is a letter
        if char.isalpha():
            letter_count += 1
        # Check if the character is a digit
        elif char.isdigit():
            digit_count += 1
        # If the character is neither a letter nor a digit, it's a symbol
        else:
            symbol_count += 1

    # Return the counts of letters, digits, and symbols
    return letter_count, digit_count, symbol_count

# Take user input for the string
input_string = input("Enter a string: ")
# Call the count_characters function with the user-provided string
letter_count, digit_count, symbol_count = count_characters(input_string)
# Print the counts of letters, digits, and symbols
print("Chars =", letter_count, "Digits =", digit_count, "Symbol =", symbol_count)
