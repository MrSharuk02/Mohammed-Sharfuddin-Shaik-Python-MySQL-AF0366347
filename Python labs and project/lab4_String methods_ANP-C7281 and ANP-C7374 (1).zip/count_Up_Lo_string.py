# Function to count uppercase, lowercase, numeric, and special characters in a string
def count_characters(input_string):
    # Initialize variables to count uppercase, lowercase, numeric, and special characters
    upper_count = 0
    lower_count = 0
    digit_count = 0
    special_count = 0

    # Iterate through each character in the input string
    for char in input_string:
        # Check if the character is uppercase
        if char.isupper():
            upper_count += 1
        # Check if the character is lowercase
        elif char.islower():
            lower_count += 1
        # Check if the character is a digit
        elif char.isdigit():
            digit_count += 1
        # If the character is neither uppercase, lowercase, nor a digit, it's a special character
        else:
            special_count += 1

    # Return the counts of uppercase, lowercase, numeric, and special characters
    return upper_count, lower_count, digit_count, special_count

# Take user input for the string
input_string = input("Enter a string: ")
# Call the count_characters function with the user-provided string
upper_count, lower_count, digit_count, special_count = count_characters(input_string)
# Print the counts of uppercase, lowercase, numeric, and special characters
print("UpperCase:", upper_count)
print("LowerCase:", lower_count)
print("NumberCase:", digit_count)
print("SpecialCase:", special_count)
