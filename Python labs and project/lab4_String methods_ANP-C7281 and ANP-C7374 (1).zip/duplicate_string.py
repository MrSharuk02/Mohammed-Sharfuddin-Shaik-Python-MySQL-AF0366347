# Function to remove duplicate characters from a string
def remove_duplicates(input_string):
    # Initialize an empty string to store the result
    result = ""
    # Initialize a set to keep track of characters already encountered
    

    # Iterate through each character in the input string
    for char in input_string.split(" "):
        # Check if the character has not been seen before
        if char not in result:
            # Add the character to the result string
            result += " "+char
     

    # Return the string with duplicate characters removed
    return result

# Take user input for the string
input_string = input("Enter a string: ")
# Call the remove_duplicates function with the user-provided string
result_string = remove_duplicates(input_string)
# Print the string with duplicate characters removed
print("String with duplicate characters removed:", result_string)
