import numpy as np
# Input category revenue arrays
category1_rev = np.array([500, 600, 700, 550])
category2_rev = np.array([450, 700, 800, 600])
# Calculate the total revenue for each category
total_revenue = category1_rev + category2_rev
print("Total Revenue:", total_revenue)
