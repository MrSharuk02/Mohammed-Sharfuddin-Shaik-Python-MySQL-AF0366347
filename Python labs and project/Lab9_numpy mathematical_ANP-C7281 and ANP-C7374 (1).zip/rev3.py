import numpy as np

def out_of_stock_products(inventory):
    out_of_stock_indices = np.where(inventory == 0)[0]
    return inventory[out_of_stock_indices]

# Example input
inventory = np.array([10, 0, 5, 0, 20, 0])

# Get the indices of out-of-stock products
out_of_stock_product = out_of_stock_products(inventory)

# Output the indices of out-of-stock products
print("Out of Stock Products:", out_of_stock_product)
