import numpy as np

def calculate_total_cost(quantity, price_per_item):
    total_cost = quantity * price_per_item
    return total_cost

# Example input
quantity = np.array([2, 3, 4, 1])
price_per_item = np.array([10.0, 5.0, 8.0, 12.0])

# Calculate the total cost of items
total_cost = calculate_total_cost(quantity, price_per_item)

# Output the total cost of items
print("Total Cost of Items:", total_cost)
