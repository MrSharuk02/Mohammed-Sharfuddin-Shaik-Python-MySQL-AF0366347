# Importing the NumPy library with an alias 'np'
import numpy as np
# Creating an array 'x' using arange() function with values from 12 to 37 (inclusive)
x = np.arange(12, 38)
# Printing the array 'x' containing values from 12 to 37
print(x)
