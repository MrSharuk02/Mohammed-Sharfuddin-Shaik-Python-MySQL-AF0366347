# Importing the NumPy library with an alias 'np'
import numpy as np

# Creating a Python list
my_list = [1, 2, 3, 4, 5, 6, 7, 8]

# Printing a message indicating the conversion of the list to an array using np.asarray() function
print("List to array: ")

# Converting the Python list to a NumPy array using np.asarray() and printing the resulting array
print(np.asarray(my_list))

# Creating a Python tuple containing two lists
my_tuple = ([8, 4, 6], [1, 2, 3])

# Printing a message indicating the conversion of the tuple to an array using np.asarray() function
print("Tuple to array: ")

# Converting the Python tuple to a NumPy array using np.asarray() and printing the resulting array
print(np.asarray(my_tuple))
