t = [(2, 5), (1, 2), (4, 4), (2, 3), (2, 1)]
temp = 0
for i in range(len(t)):
    for i in range(1,len(t)):
        o = 1
        if t[i-1][o] < t[i][o]:
            continue
        else:
            temp = t[i]
            t[i] = t[i-1]
            t[i-1] = temp
       
print(t)
