l1=[1,2,3,4,5,6,1,3,5,2,5,7,7,5,2,3]
unique=[]
duplicate=[]
for x in l1:
    if x not in unique:
        unique.append(x)
    elif x in duplicate:
        continue
    else:
        duplicate.append(x)
print(duplicate)
