OL=[1,1,2,3,4,4,5,1]
len=int(input("Enter Length:"))
firstList=OL[:len]
endList=OL[len:]
splittedList=[firstList,endList]
print(splittedList)
