''' Write a function to find the Factorial of a number '''
def fact(n):                # Funtion declaration
    if n == 0:              # Condition Cheaking
        return 1
    else:
        return n * fact(n - 1)
n = int(input("Enter the no: "))    # User input
print("Factorial of", n, "is", fact(n)) #Output
