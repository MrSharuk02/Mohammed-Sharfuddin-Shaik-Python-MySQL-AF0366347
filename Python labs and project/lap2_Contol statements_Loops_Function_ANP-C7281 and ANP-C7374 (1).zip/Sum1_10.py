''' Calculate the sum of numbers from 1 to 10 '''
I = 1               #Intializiation
Sum = 0             #Intializiation
for i in range(11): #Loop
    Sum += i        #Summing
print("The Sum of 1 to 10 is",Sum)  #Output
