''' Create a Python program that checks if a user-given number is positive, negative, or zero '''
N = int(input("Enter the Number: "))        #Enter the User input
if N > 0:                                   #Codition cheaking
    print("The Number",N,"is Positive")
elif N < 0:
    print("The Number",N,"is Negative")
else:
    print("The Number",N,"is Zero")
