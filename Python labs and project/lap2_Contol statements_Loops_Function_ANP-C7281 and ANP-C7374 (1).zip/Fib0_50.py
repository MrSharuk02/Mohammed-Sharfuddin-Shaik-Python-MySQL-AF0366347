''' Write a Python program to get the Fibonacci series between 0 and 50 '''
# Initialize variables for Fibonacci sequence
a, b = 0, 1

# Generate Fibonacci series up to 50
fib_series = []
while a < 50:
    # Print current Fibonacci number
    print(a, end=" ")
    # Update variables for next Fibonacci number
    a, b = b, a + b

print("\nFibonacci series printed between 0 and 50.")
