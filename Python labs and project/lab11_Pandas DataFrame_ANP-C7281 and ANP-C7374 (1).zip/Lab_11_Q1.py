import pandas as pd

# List of students
students = ['Alice', 'Bob', 'Charlie', 'David', 'Eve', 'Frank', 'Grace', 'Hannah', 'Ivy', 'Jack']

# List of exam scores corresponding to each student
exam_scores = [92, 88, 76, 94, 82, 90, 85, 89, 78, 91]

# Creating a Pandas Series with students as index and exam scores as values
exam_scores_series = pd.Series(exam_scores, index=students)

# Printing the Pandas Series
print(exam_scores_series)
