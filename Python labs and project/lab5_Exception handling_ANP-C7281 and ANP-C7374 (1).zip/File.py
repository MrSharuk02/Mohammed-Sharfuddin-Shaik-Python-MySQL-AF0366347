#opens the file anudip.txt in write mode
try:
    fileobj = open("D:\\Anudip\\abc.txt","w")
    #The file is not found so exception has been occured
except FileNotFoundError:
    print("the file does not exist")

