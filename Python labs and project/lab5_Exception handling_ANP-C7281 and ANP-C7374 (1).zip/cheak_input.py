#Function Defined to cheak the input is valid integer or not and raise a exception.
def cheak_input():
    #try block accepts a value
    try:
        k = int(input())
        return k
    #if the value error occurs the except handle the exception.
    except ValueError:
        return "It's an invalid input"
#function call
Result = cheak_input()
#Output of the function
print(Result)
