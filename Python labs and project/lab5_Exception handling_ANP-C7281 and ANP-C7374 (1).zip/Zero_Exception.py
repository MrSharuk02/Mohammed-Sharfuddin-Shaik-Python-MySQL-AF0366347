#Function Defined to Divide two numbers
def Zero_Div(Num1,Num2):
    #try block cheak for exception
    try:
        Result = int(Num1/Num2)
        # if no exception detected then the result will print
        return Result
    # except block handles the Exception and return the user message inted of an Error.
    except ZeroDivisionError:
        return "Zero division error has occured"
# taking input from the users 
K,L = map(int,input("Enter the Num1 and Num2: ").split())
#function call to divide the two numbers
R = Zero_Div(K,L)
#prints the returned value of the funtion.
print(R)
