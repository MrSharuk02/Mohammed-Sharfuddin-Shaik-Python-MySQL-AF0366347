dict1={1:10,2:20}
dict2={3:30,4:40}
dict3={5:50,6:60}
concated={}
concated.update(dict1)
concated.update(dict2)
concated.update(dict3)
print("Concatenated dictionary:")
print(concated)
